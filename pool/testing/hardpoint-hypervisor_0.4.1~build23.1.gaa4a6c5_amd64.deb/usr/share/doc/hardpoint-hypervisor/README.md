# HardPoint Hypervisor

A Proxmox-style virtualization host with a simple, secure web UI. It turns a
server (or a mini PC) into a KVM host where you can create VMs and Linux
containers, open their screens in the browser, share folders, run a VPN and
back everything up on a schedule.

It's built the same way Proxmox is: proven Linux virtualization underneath
(KVM + QEMU + libvirt on Debian 13), with HardPoint's own management service
and web UI on top.

## Status: v0.4.1

| Area | What you get |
|---|---|
| Install | Installer ISO (BIOS + UEFI), or `.deb` on an existing Debian 13; handles servers where the install disk isn't the first disk, and old Proxmox (thin LVM) installs |
| VMs | Templates (VPN, file server, Windows/Linux desktop, custom); start, shut down, force stop, reboot, pause, delete; **edit** CPU/RAM/disk size; **clone** |
| Snapshots | Save points of a VM's disks (taken while the VM is off), restore or delete them |
| Import | Upload a qcow2 / raw / VMDK / VHD(X) disk (e.g. exported from Proxmox) and create a VM from it |
| Console | In-browser screen (noVNC), Ctrl+Alt+Del, type-clipboard, fullscreen |
| Storage | All drives with SMART health; turn an unused drive into a storage volume |
| RAID cards | MegaRAID-family cards: health of the drives behind the card; with StorCLI, volume states, cache battery (start a learn cycle) and alarm, with a warning banner |
| Shares | SMB (Windows/Mac/phones) and NFS (Linux) shared folders, share users with passwords |
| VPN | Built-in WireGuard: add a phone with a QR code; reach the server, your home network, or route all traffic |
| Windows 11 | UEFI + Secure Boot + virtual TPM, SATA/e1000e so no extra drivers needed |
| Networking | `vmbr0` bridge to your LAN (set up by the installer), libvirt NAT network |
| Dashboard | CPU, memory, storage, uptime, CPU model, VT-x / KVM / IOMMU checks |
| Containers | Lightweight Linux containers (Incus/LXC): Debian, Ubuntu, Alpine, Rocky, Arch; bridged or NAT network, CPU/RAM limits, autostart, optional Docker-inside; **browser terminal** |
| Backups | Back up a VM to any storage volume (live while running, or offline), compressed; restore as a new VM or over the original; **schedules** (daily/weekly, keep last N) with an activity list |
| Firewall | Host firewall (nftables): limit web UI/SSH and file sharing to networks you choose, extra port rules; your own address is checked so you can't lock yourself out, and changes roll back after 90 s unless confirmed |
| Users | Multiple accounts with roles: **admin** (everything), **operator** (start/stop, consoles, terminals, backups), **viewer** (look only) |
| VM storage | Put a new VM's disk on any storage volume instead of the system drive |
| Updates | In-place updates from a signed package archive: banner when a new version is out, one click in Settings → Updates; stable and testing channels |

Roadmap: v1.0 2FA/passkeys, usage graphs, mirrored storage volumes, backup to
another machine · v2.0 clustering / live migration across mini PCs.

First real hardware: a Lenovo ThinkServer RD530 (2× Xeon E5-2640, LSI 9260-8i RAID).
Containers, backups, firewall, shares and the VPN pass the automated tests but
haven't been used on it yet.

## Security design

- HTTPS only (TLS 1.2+), self-signed cert generated on first boot; its SHA-256
  fingerprint is printed on the server's screen so you can verify the browser warning.
- First-run setup needs a one-time token shown on the server's physical console,
  so nobody else on the network can claim the admin account first.
- Passwords: PBKDF2-SHA256, 600,000 iterations, 12+ characters.
- Login lockout after 5 failures (15 min), constant-time checks, no user enumeration.
- Sessions: random 256-bit, HttpOnly + Secure + SameSite=Strict cookies, 1 h idle /
  8 h max; CSRF token on every change; cross-origin requests rejected.
- Strict Content-Security-Policy, no frames, no inline scripts; all UI text is
  rendered as text (no HTML injection).
- VM consoles listen only on 127.0.0.1 and are reached through a one-time,
  30-second ticket bound to one VM; container terminals use the same kind of
  ticket, bound to one container and one user.
- Roles are enforced on the server for every API call, not just hidden in the UI.
  The last admin can't be removed or demoted.
- Firewall changes are checked against the address you're connected from, only
  kept once a brand-new connection gets through them, and undone automatically
  after 90 seconds otherwise (also if the agent restarts). Console off switch:
  `sudo hpvd firewall off`.
- The agent's own state (shares, VPN keys, firewall) lives in a root-only folder
  (`/var/lib/hpvd-agent`) and is re-validated every time it's read.
- The web service has no access to libvirt (it is not in the `libvirt` or `kvm`
  groups). Every VM operation is a validated request to `hpvd-agent`; nothing
  the web service sends reaches libvirt as XML or as a file path.
- VM disks, ISOs and snapshot metadata live in root-owned folders. ISO uploads
  land in a staging folder and are moved in and checked by the agent; uploaded
  disk images for import are only ever read by `qemu-img` running as the
  unprivileged user (an image can reference other host files).
- Backup folders must be root-owned, and share folders can't use HardPoint's
  own folder names.
- Consoles and terminals close when your session ends (sign-out, role or
  password change, account removal, expiry), and are capped per user.
- The web service runs as an unprivileged `hardpoint` user under a locked-down
  systemd sandbox. Root-only work (formatting drives, Samba/NFS/WireGuard config,
  share users, firewall, backups, containers, VMs) goes through `hpvd-agent`: a root helper that only accepts the
  hardpoint user on its unix socket and only performs a fixed list of validated
  operations. Commands are run directly (never via a shell).
- Erasing a drive needs the drive's serial number typed in and your password again.
- Share users are separate accounts that can't log in to the server or the web UI;
  SMB requires SMB2+, signing and no guest access. NFS shares are limited to the
  network you enter.
- VPN device keys are generated on the server and shown once as a QR code; the
  device's private key is never stored.
- Audit log of every login and change: `journalctl -u hpvd`.
- Zero third-party Go dependencies (standard library only). Bundled browser
  libraries: noVNC (MPL-2.0), xterm.js and qrcode-generator (MIT).

## Install

See [docs/INSTALL.md](docs/INSTALL.md). Testing on real hardware:
[docs/HARDWARE-TEST.md](docs/HARDWARE-TEST.md). Security design and threat
model, for reviewers: [docs/SECURITY.md](docs/SECURITY.md).

## Development

```sh
go test ./...
# UI with fake VMs, no libvirt needed (prints a setup token):
go run ./cmd/hpvd serve -demo -dev-http -listen 127.0.0.1:8099 -config-dir /tmp/hp/etc -data-dir /tmp/hp/data
packaging/build-deb.sh            # -> dist/hardpoint-hypervisor_<ver>_amd64.deb
iso/build-iso.sh --deb dist/*.deb --out dist/hardpoint.iso   # needs xorriso, cpio, debian-keyring
```

Layout: `cmd/hpvd` daemon/CLI · `internal/api` web API · `internal/agent` root
helper (VMs, storage, shares, VPN, firewall, backups, containers) ·
`internal/vm` VM driver (libvirt via virsh, run by the agent) · `internal/auth`,
`internal/console` WebSocket proxy · `web/static` UI (plain JS, no build step;
noVNC vendored under MPL-2.0, qrcode-generator under MIT) · `packaging/` .deb + systemd · `iso/` installer
remaster · `ci/` automated install test.

Release process: push a `vX.Y.Z` tag (it must match `VERSION`), then bump
`VERSION` to the next version so later test builds sort after the release.

Releases: the **ISO** workflow builds the installer, installs it in a VM to
test it, and publishes it on the Releases page — as a "Test build" pre-release
when run by hand (Actions → ISO → Run workflow), or as a real release when a
`vX.Y.Z` tag is pushed.
